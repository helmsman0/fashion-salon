const sr = ScrollReveal({
    distance: '50px',
    duration: 2550,
    reset: true
});

sr.reveal('.container',{delay:300});
